package fr.artus25200.automations.common.node.events;

import java.util.ArrayList;

import fr.artus25200.automations.common.Automations;
import fr.artus25200.automations.common.node.Node;
import fr.artus25200.automations.common.node.Nodes;
import fr.artus25200.automations.common.node.Output;
import fr.artus25200.automations.common.node.action.Action;


public abstract class EventNode extends Node implements HasParent {
    public Output actionOutput;
    
    @Override
    public int getColor() {
        return 0xFFfAEB61;
    }


    @Override
    public boolean Execute() {
        this.onExecute();
        if(this.actionOutput.isConnected()){
            return this.actionOutput.connections.get(0).input.parent.Execute();
        }
        return false;
    }

    @Override
    public void setInputs() {
        // no inputs
    }

    @Override
    public void setOutputs() {
        this.actionOutput = new Output(this, "Action", Action.class);
        this.outputs.add(this.actionOutput);
    }

    @Override
    public boolean onExecute() {
        Automations.LOGGER.info("Event triggered : " + this.getName() + ". Executing ActionNode : " + (this.actionOutput.isConnected() ? this.actionOutput.connections.get(0).input.parent.getName() : "None") + ".");
        return true;
    }

    public abstract void registerEvent();

    public ArrayList<Node> GetParents(){
        ArrayList<Node> list = new ArrayList<>();
        list.add(this);
        return list;
    }
}
